//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DfuSeDemo.rc
//
#define IDCANCEL2                       3
#define IDC_BUTTONABORT                 3
#define IDD_DfuSeDemo_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_DfuSeMapping_DIALOG         129
#define IDD_OPTION_BYTE_DIALOG          135
#define IDD_OPTION_BYTE_F2_DIALOG       136
#define IDD_OPTION_BYTE_L1_DIALOG       137
#define IDC_COMBODEVICES                1000
#define IDC_BUTTONREFRESH               1001
#define IDC_EDITDEVVID                  1002
#define IDC_EDITDEVPID                  1003
#define IDC_EDITDEVBCD                  1004
#define IDC_LISTDEVTARGETS              1005
#define IDC_COMBOTARGETS                1006
#define IDC_BUTTONUPCHOOSE              1007
#define IDC_BUTTONDOWNCHOOSE            1008
#define IDC_EDITFILEVID                 1009
#define IDC_EDITFILEPID                 1010
#define IDC_EDITFILEBCD                 1011
#define IDC_BUTTONENTERDFU              1012
#define IDC_LISTFILETARGETS             1013
#define IDC_EDITSTART                   1014
#define IDC_EDITSTOP                    1015
#define IDC_BUTTONUPLOAD                1016
#define IDC_STATICUPFILE                1017
#define IDC_BUTTONUPGRADE               1018
#define IDC_LISTDFUDEVS                 1019
#define IDC_BUTTONENTERAPP              1020
#define IDC_STATICDOWNFILE              1021
#define IDC_PROGRESS                    1022
#define IDC_BUTTONVERIFY                1023
#define IDC_LISTTARGETS                 1024
#define IDC_EDITDEVVID2                 1026
#define IDC_EDITDEVPID2                 1027
#define IDC_EDITDEVBCD2                 1028
#define IDC_EDITDEVVID3                 1029
#define IDC_REPORT                      1031
#define IDC_LISTMAPPING                 1032
#define IDC_CHECKUPLOAD                 1033
#define IDC_CHECKDNLOAD                 1034
#define IDC_CHECKCANDETACH              1035
#define IDC_CHECKMANIFTOL               1036
#define IDC_CHECKUPLOADACC              1037
#define IDC_CHECKUPGRADEOPTIMIZE        1038
#define IDC_TIME_DURATION               1040
#define IDC_VERIFY                      1041
#define IDC_DATA_SIZE                   1042
#define IDC_RDP_EDIT                    1045
#define IDC_READ_OUT_PROTECTION_ENABLED_CHECK 1046
#define IDC_USER_EDIT                   1047
#define IDC_NRST_STDBY_CHECK            1048
#define IDC_NRST_STOP_CHECK2            1049
#define IDC_WDG_SW                      1050
#define IDC_DATA0_EDIT                  1051
#define IDC_BF2                         1051
#define IDC_BFB2                        1051
#define IDC_DATA1_EDIT                  1052
#define IDC_WRP0_EDIT                   1053
#define IDC_WRP1_EDIT                   1054
#define IDC_WRP2_EDIT                   1055
#define IDC_WRP3_EDIT                   1056
#define ID_APPLY                        1057
#define IDC_READ_OUT_PROTECTION_ENABLED_CHECK2 1058
#define IDC_READ_OUT_PROTECTION_ENABLED_CHECK3 1059
#define IDC_BOR_LEV1                    1060
#define IDC_BOR_LEV2                    1061
#define IDC_BOR_LEV0                    1061
#define IDC_WRP_EDIT                    1062
#define IDC_BOR_LEV3                    1062
#define IDC_BOR_LEV4                    1063
#define IDC_WRP4_EDIT                   1064
#define IDC_WRP6_EDIT                   1065
#define IDC_WRP8_EDIT                   1066
#define IDC_WRP10_EDIT                  1067

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1063
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
