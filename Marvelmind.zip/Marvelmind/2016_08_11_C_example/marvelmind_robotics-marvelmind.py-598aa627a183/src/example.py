from marvelmind import MarvelmindHedge
from time import sleep
import sys

def main():
    hedge = MarvelmindHedge(tty = "/dev/ttyACM3") # create MarvelmindHedge thread
    hedge.start() # start thread
    while True:
        try:
            sleep(3)
            print (hedge.position()) # get last position and print
        except KeyboardInterrupt:
            hedge.stop()  # stop and close serial port
            sys.exit()
main()